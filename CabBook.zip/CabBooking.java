
import java.io.Serializable;

/**
 * Hello world!
 *
 */
class CabBooking implements Serializable{ 
private int otp;
private String pickUp;
private String drop;
private String mobileNo;
private String cabType;

	CabBooking(String pickUp, String drop, String mobileNo, String cabType) {
		this.pickUp = pickUp;
		this.drop = drop;
		this.mobileNo = mobileNo;
		this.cabType = cabType;

	}

	public void setOtp(int otp) {
		this.otp = otp;
	}
	public int getOtp() {
		return this.otp;
	}
	public String getPickUp() {
		return this.pickUp;
	}
	public String getdDrop() {
		return this.drop;
	}
	public String getMobileNo() {
		return this.mobileNo;
	}
	public String getCabType() {
		return this.cabType;
	}


@Override
	public String toString() {
System.out.println("pickup:-"+getPickUp());
System.out.println("drop:-"+getdDrop());
System.out.println("mobile no:-"+getMobileNo());
System.out.println("cab type:-"+getCabType());

	return super.toString();
	}

}