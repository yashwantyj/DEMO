
import java.io.IOException;
import java.util.Scanner;

public class CabClient {
	public static void main(String[] args) {
		System.out.println("############WELCOME to RIDE ON CAB SERVICES###############");
		System.out.println("");
		while (true) {
			System.out.println("-------------MENU--------------");
			System.out.println("1. Book a Cab \n" + "2. Read Cab Details from File\n" + "3. Exit.");
			System.out.println("Enter Your choice:-");
			Scanner sc = new Scanner(System.in);
			int op = sc.nextInt();
			switch (op) {
			case 1:
				try {
					System.out.println("Enter Mobile No:-");
					String mobno = sc.next();
					CabDataValidator.validateMobile(mobno);
					System.out.println("Enter Otp send on " + mobno);
					int otp = sc.nextInt();
					CabDataValidator.validateOtp("" + otp);
					System.out.println("Enter Pickup:-");
					String pickup = sc.next();
					System.out.println("Enter drop");
					String drop = sc.next();
					System.out.println("Enter Cab Type");
					String cabType = sc.next();
					CabDataValidator.validateCabType(cabType);
					CabBooking cab = new CabBooking(pickup, drop, mobno, cabType);
					new CabFileHelper().writeCabDetails(cab);
					System.out.println("-------------Done Your Cab is booked--------------");

				} catch (CabException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case 2:
				try {
					new CabFileHelper().readCabDetailsFromFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case 3:
				System.out.println("Thank you Ride with us");
				System.exit(0);
				break;
			}

		}
	}
}
