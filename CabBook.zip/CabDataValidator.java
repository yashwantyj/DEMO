
import java.util.regex.Pattern;

public class CabDataValidator {
	public  static  boolean validateOtp(String otp)throws CabException
	{
		String custPattern="\\d{4}";
		if(Pattern.matches(custPattern, otp))
		{
			return true;
		}
		else
		{
			throw new CabException("Cab otp should 4Digit Max");
		}
	}
	
	public  static  boolean validateMobile(String CabId)throws CabException
	{
		String IdPattern="^[6-9]\\d{9}$";

		if(Pattern.matches(IdPattern, CabId))
		{
			return true;
		}
		else
		{
			throw new CabException("Only 10-digit mobile no is Allowed");
		}
	}
	
	public  static  boolean validateCabType(String CabType)throws CabException
	{
		if(CabType.isEmpty()||!"".equals(CabType))
		{
			return true;
		}
		else
		{
			throw new CabException("Cab type cannot be empty");
		}
	}
}
