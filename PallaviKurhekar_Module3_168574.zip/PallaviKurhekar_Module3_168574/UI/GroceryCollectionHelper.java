package com.cg.UI;

import java.io.IOException;
import java.util.ArrayList;


public class GroceryCollectionHelper {
	
	
static ArrayList<GrocerySchema> grocery = new ArrayList<GrocerySchema>();
public void addGrocery(GrocerySchema gs) throws IOException
{
	grocery.add(gs);
	 
}
	public void readGrocery() {
		for(GrocerySchema gs:grocery) {
			gs.toString();
		}
	}
}
	