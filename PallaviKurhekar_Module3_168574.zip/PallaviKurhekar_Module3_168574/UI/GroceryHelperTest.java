package com.cg.UI;


import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;



public class GroceryHelperTest {
	static GroceryCollectionHelper collectionHelper;
	static GrocerySchema grocery=null;
	
	@BeforeClass
	public   static  void beforeClass()
	{
		collectionHelper=new GroceryCollectionHelper();
		grocery =new GrocerySchema("12345","Apple","Fruit",2);		
	}
	@AfterClass
	public static  void afterClass()
	{		
		collectionHelper=null;
		grocery=null;
	}	
	
	
	//@SuppressWarnings("deprecation")
	@Test 
	public void testAddNewBook() throws GroceryException
	{
		collectionHelper.addDetails(grocery);
		//Assert.assertEquals(1, GroceryCollectionHelper.displayGroceryCount());
		Assert.assertNotNull(collectionHelper.toString());
	}	
}

