package com.cg.UI;

import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;


public class GroceryDataValidator {
	static List<String> type = new ArrayList<String>();
	static {
		type.add("Fruit");
		type.add("Vegetable");
		type.add("Beverages");
	}

	public static boolean validateGrocery(String groceryName) throws GroceryException {
		String name= "^[a-zA-Z]{3,20}";
		if(Pattern.matches(name, groceryName))
		{
			return true;
		}
		else
		{
			throw new GroceryException("Grocery name should be minimum 3 letters.Enter valid Grocery name");
		}
	}

	public static boolean validateType(String Type) throws GroceryException {
		if ((Type.isEmpty() || !"".equals(Type)) && type.contains(Type)) {
			return true;
		} else {
			throw new GroceryException("It is not any grossary type");
		}
	}

	public static boolean validateQuantity(String groceryQuantity) throws GroceryException {
		String custPattern = "\\d+";

		if (Pattern.matches(custPattern, groceryQuantity)) {
			return true;
		} else {
			throw new GroceryException("Quntity should be digit");
		}
	}

	public static boolean validateDate(String date) throws GroceryException {
		String custPattern = "^\\d{2}-\\d{2}-\\d{4}$";

		if (Pattern.matches(custPattern, date)) {
			return true;
		} else {
			throw new GroceryException("date should be in format dd-mm-yyyy");
		}
	}
}

