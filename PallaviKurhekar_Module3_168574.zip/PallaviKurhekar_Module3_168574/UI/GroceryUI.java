
package com.cg.UI;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class GroceryUI {
	public static void main(String[] args) {
		System.out.println("############WELCOME to BIG BOWL Online Grocery Store###############");
		System.out.println("");
		while (true) {
			System.out.println("-------------MENU--------------");
			System.out.println("1. Enter Grocery Details \n" + "2. Exit.");
			System.out.println("Enter Your choice:-");
			Scanner sc = new Scanner(System.in);
			int op = sc.nextInt();
			switch (op) {
			case 1:
				try {
					System.out.println("Enter Grossary  Name:");
					String name = sc.next();
					GroceryDataValidator.validateGrocery(name);
					System.out.println("Enter Type:");
					String type = sc.next();
					GroceryDataValidator.validateType(type);
					System.out.println("Enter Date:");
					String dt = sc.next();
					GroceryDataValidator.validateDate(dt);
					System.out.println("Enter Quntity");
					String groceryQuantity = sc.next();
					GroceryDataValidator.validateQuantity(groceryQuantity);
					int referenceId = new Random().nextInt(10000);// Random number for ref ID
					GrocerySchema gs = new GrocerySchema(groceryQuantity,name,type,referenceId);
					new GroceryCollectionHelper().addGrocery(gs);
					
					System.out.println("-------------Done--------------");
					System.out.println("-------------Details As follow--------------");

					new GroceryCollectionHelper().readGrocery();

				} catch (GroceryException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} /*catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/

				break;
			
			case 2:
				System.out.println("Thank you for Shopping with us");
				System.exit(0);
				break;
			}

		}
	}
}
