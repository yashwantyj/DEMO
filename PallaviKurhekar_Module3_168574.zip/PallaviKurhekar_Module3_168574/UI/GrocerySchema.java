package com.cg.UI;

public class GrocerySchema {
	private String referenceId;
	private String groceryName;
	private String groceryType;
	private int groceryQuantity;
	
	

	
	public GrocerySchema(String referenceId,String groceryName,String groceryType,int groceryQuantity) {
		super();
		this.referenceId = referenceId;
		this.groceryName = groceryName;
		this.groceryType = groceryType;
		this.groceryQuantity = groceryQuantity;
		
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getGroceryName() {
		return groceryName;
	}

	public void setGroceryName(String groceryName) {
		this.groceryName = groceryName;
	}

	public String getGroceryType() {
		return groceryType;
	}

	public void setGroceryType(String groceryType) {
		this.groceryType = groceryType;
	}

	public int getGroceryQuantity() {
		return groceryQuantity;
	}

	public void setGroceryQuantity(int groceryQuantity) {
		this.groceryQuantity = groceryQuantity;
	}

	@Override
	public String toString() {
		return "Grocery [Reference_Id=" + referenceId + ", GroceryName="
				+ groceryName + ", GroceryType=" + groceryType + ",GroceryQuantity= " + groceryQuantity + "]";
	}
}
